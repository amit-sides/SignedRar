# SignedZip
This project consists of a  program that allows users to cryptographically sign ZIP files.
